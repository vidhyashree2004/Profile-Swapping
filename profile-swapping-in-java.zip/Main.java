import java.util.*;
public class Main 
{  
public static void main(String[] args)  
{  
    Scanner Sc=new Scanner(System.in);
    int n=Sc.nextInt();
    if(n==1)
    {
        System.out.println(1);
    }
    else{
    for(int i=3;i<=n;i++)
    {
int a=1;
int b=1;
int c;
c=a+b;
a=b;
b=c;
System.out.println(b);  
}  
}  
}
}